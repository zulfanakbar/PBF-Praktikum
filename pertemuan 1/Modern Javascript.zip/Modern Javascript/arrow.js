let gretting = message => alert(`${message} Cantik!`);
gretting('Selamat Pagi');