let[wife] = ['Ratna', 'Bunga', 'Tiara'];
alert(wife);