const name = 'Polinema';
alert(name);