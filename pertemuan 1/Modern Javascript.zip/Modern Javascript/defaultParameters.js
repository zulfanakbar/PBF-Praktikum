function welcome(user = 'Cantik', message = 'Selamat beraktifitas dan jangan lupa makan yah') {
    alert(`Hai ${user}, ${message}`);
}

welcome();