var pemainSepakBola = {
    name: 'Salah',
    height: '175',
    output(){
        alert(`Mr. ${this.name} is ${this.height} centimeter tall`);
    }
};
pemainSepakBola.output();