var rivers = ['Ciliwung', 'Brantas', 'Begawan Solo'];
var [first, ...rest] = rivers;

alert(rest);