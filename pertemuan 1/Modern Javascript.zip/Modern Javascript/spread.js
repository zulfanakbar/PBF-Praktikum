var mountains = ['Semeru', 'Bromo', 'Merapi'];
var mountainsFromJapan = ['Fuji'];

var allMountains = [...mountains, ...mountainsFromJapan];
alert(allMountains);