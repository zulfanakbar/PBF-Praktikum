let polStudent = ({name, polytechnic}) => {
    alert(`${name} from ${polytechnic}`);
}

polStudent({
    name: 'Ronaldo',
    polytechnic: 'Politeknik Negeri Malang'
});