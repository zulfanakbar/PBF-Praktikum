let fname = 'Cristian';
let lname = 'Ronaldo';
let age = prompt("Masukkan umur Cristian Ronaldo!");

// let result = fname + ' ' + lname + ' is ' + age + ' years old ';

let result = `${fname} ${lname} is ${age} years old`;
alert(result);