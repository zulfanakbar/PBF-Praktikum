if (true) {
    let name = 'Polinema';
    name = 'Politeknik Negeri Malang'
    alert(name);
}