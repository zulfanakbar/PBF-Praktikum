const func = (a, b) => {
    return a + b;
};
alert(func(5, 4));